/**
 * Created by Administrator on 2018/3/17 0017.
 */
/*这里存放dB数据库的配置项*/


var app={

    dbUrl: 'mongodb://106.14.15.229:27017/',

    dbName: 'test'

}

module.exports=app;