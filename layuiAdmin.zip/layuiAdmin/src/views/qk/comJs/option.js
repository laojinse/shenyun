var qkOption = {
    // 下拉框
    // 业务类型
    busType: [{
            label: '--请选择--',
            value: ''
        },
        {
            label: '全部',
            value: '全部'
        },
        {
            label: '国内商标注册',
            value: '国内商标注册'
        },
        {
            label: '集体商标注册',
            value: '集体商标注册'
        },
        {
            label: '证明商标注册',
            value: '证明商标注册'
        },
        {
            label: '马德里注册',
            value: '马德里注册'
        },
        {
            label: '单一国家注册',
            value: '单一国家注册'
        },
        {
            label: '国内商标变更',
            value: '国内商标变更'
        },
        {
            label: '国内许可备案',
            value: '国内许可备案'
        },
        {
            label: '国内出具证明',
            value: '国内出具证明'
        },
        {
            label: '国内商标转让',
            value: '国内商标转让'
        },
        {
            label: '国内商标续展',
            value: '国内商标续展'
        },
        {
            label: '国内商标评审',
            value: '国内商标评审'
        },
        {
            label: '国内商标异议',
            value: '国内商标异议'
        },
        {
            label: '国内商标补发',
            value: '国内商标补发'
        },
        {
            label: '国内商标无效',
            value: '国内商标无效'
        }
    ],
    // 商标类别
    tradeCate: [{
            label: '--请选择--',
            value: ''
        },
        {
            label: '全部',
            value: '全部'
        },
        {
            label: '01',
            value: '01'
        },
        {
            label: '02',
            value: '02'
        },
        {
            label: '03',
            value: '03'
        },
        {
            label: '04',
            value: '04'
        },
        {
            label: '05',
            value: '05'
        },
        {
            label: '06',
            value: '06'
        },
        {
            label: '07',
            value: '07'
        },
        {
            label: '08',
            value: '08'
        },
        {
            label: '09',
            value: '09'
        },
        {
            label: '10',
            value: '10'
        },
        {
            label: '11',
            value: '11'
        },
        {
            label: '12',
            value: '12'
        },
        {
            label: '13',
            value: '13'
        },
        {
            label: '14',
            value: '14'
        },
        {
            label: '15',
            value: '15'
        },
        {
            label: '16',
            value: '16'
        },
        {
            label: '17',
            value: '17'
        },
        {
            label: '18',
            value: '18'
        },
        {
            label: '19',
            value: '19'
        },
        {
            label: '20',
            value: '20'
        },
        {
            label: '21',
            value: '21'
        },
        {
            label: '22',
            value: '22'
        },
        {
            label: '23',
            value: '23'
        },
        {
            label: '24',
            value: '24'
        },
        {
            label: '25',
            value: '25'
        },
        {
            label: '26',
            value: '26'
        },
        {
            label: '27',
            value: '27'
        },
        {
            label: '28',
            value: '28'
        },
        {
            label: '29',
            value: '29'
        },
        {
            label: '30',
            value: '30'
        },
        {
            label: '31',
            value: '31'
        },
        {
            label: '32',
            value: '32'
        },
        {
            label: '33',
            value: '33'
        },
        {
            label: '34',
            value: '34'
        },
        {
            label: '35',
            value: '35'
        },
        {
            label: '36',
            value: '36'
        },
        {
            label: '37',
            value: '37'
        },
        {
            label: '38',
            value: '38'
        },
        {
            label: '39',
            value: '39'
        },
        {
            label: '40',
            value: '40'
        },
        {
            label: '41',
            value: '41'
        },
        {
            label: '42',
            value: '42'
        },
        {
            label: '43',
            value: '43'
        },
        {
            label: '44',
            value: '44'
        },
        {
            label: '45',
            value: '45'
        },
    ],
    // 案件状态
    caseState: [{
        label: '--请选择--',
        value: ''
    }, {
        label: '全部',
        value: '全部'
    }, {
        label: '等待提审',
        value: '等待提审'
    }, {
        label: '报件审核',
        value: '报件审核'
    }, {
        label: '审核失败',
        value: '审核失败'
    }, {
        label: '商标申报',
        value: '商标申报'
    }, {
        label: '商标受理',
        value: '商标受理'
    }, {
        label: '形式审查',
        value: '形式审查'
    }, {
        label: '不予受理',
        value: '不予受理'
    }, {
        label: '补正通知',
        value: '补正通知'
    }, {
        label: '补正审查',
        value: '补正审查'
    }, {
        label: '实质审查',
        value: '实质审查'
    }, {
        label: '驳回通知',
        value: '驳回通知'
    }, {
        label: '驳回复审',
        value: '驳回复审'
    }, {
        label: '初步审定',
        value: '初步审定'
    }, {
        label: '异议通知',
        value: '异议通知'
    }, {
        label: '异议答辩',
        value: '异议答辩'
    }, {
        label: '核准公告',
        value: '核准公告'
    }, {
        label: '无效通知',
        value: '无效通知'
    }, {
        label: '无效答辩',
        value: '无效答辩'
    }, {
        label: '已注册',
        value: '已注册'
    }, {
        label: '待续展',
        value: '待续展'
    }, {
        label: '宽展期',
        value: '宽展期'
    }, {
        label: '已无效',
        value: '已无效'
    }, {
        label: '延期审查',
        value: '延期审查'
    }, {
        label: '同日申请',
        value: '同日申请'
    }],
    // 标签
    label: [{
            label: '--请选择--',
            value: ''
        }, {
            label: '全部',
            value: '全部'
        }, {
            label: '保授权',
            value: '保授权'
        }, {
            label: '未清款',
            value: '未清款'
        }, {
            label: '合作方',
            value: '合作方'
        }, {
            label: '自定义',
            value: '自定义'
        }
    ]
}