const router = require('koa-router')()
const DB = require('../modules/db.js');


router.get('/', async (ctx, next) => {
  await ctx.render('/index')
})

router.get('/string', async (ctx, next) => {
  ctx.body = 'koa2 string'
})

router.get('/json', async (ctx, next) => {
  ctx.body = {
    title: 'koa2 json'
  }
})

//执行增加学员的操作
router.get('/doAdd',async (ctx)=>{

  //获取表单提交的数据

 // console.log(ctx.request.body);  //


  let data=await DB.insert('testuser',{ username: '王麻子', age: '12', sex: '1' });
  //console.log(data);
  try{
      if(data.result.ok){
          ctx.redirect('/')
      }
  }catch(err){
      console.log(err);
      return;
      ctx.redirect('/add');
  }



})

module.exports = router
