const router = require('koa-router')()
const DB = require('../modules/db.js');

router.prefix('/menu')

// 获取列表
router.get('/', async (ctx, next) => {
  console.log('进来了menu 目标获取目录列表');
  //设置基础值 data就是 列表项 传输出去的值 也是这个
  let menuL = { "code": "0" ,"msg": "" ,"data": []} ;
  // 获取所有菜单的值 数据表 
  let menuArry =  await DB.insert('menuS',ctx.query) ;
  // 在这个位置生成菜单JSON

  // menuArry.forEach(element => {
  //   if() 写到这里了========================================在这拼凑
  // });
  ctx.body = '进来了menu'

})

// 添加菜单
router.get('/addmenu', async (ctx, next) => {

  //第一步 存该值到 menuS表中
    let data = await DB.insert('menuS',ctx.query)
  //第二步 返回上一页刷新上一页页面
    try{
        if(data.result.ok){
          ctx.body = '<script>window.history.back(-1); </script>'
        }
    }catch(err){
        ctx.body = '<script>alert("服务器链接超时")window.history.back(-1); </script>'
    }

  await next();

})

// 获取菜单列表
router.get('/menuList', async(ctx,next) =>{

  //向接口拿数据
  let data = await DB.find('menuS',{})

  ctx.body = data

} )

 
module.exports = router
