{
    "code": 0,
    "msg": "",
    "data": [{
        "id": "CRM",
        "name": "客户管理",
        "sort": "0",
        "url": "qk/custom/cusSummary/cusSummary.html",
        "list": [{
                "id": "cusSummary",
                "name": "客户汇总",
                "url": "qk/custom/cusSummary/cusSummary.html",
                "sort": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    },
                    {
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    },
                    {
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    }
                ]
            },
            {
                "id": "docRecord",
                "name": "跟单记录",
                "sort": "2",
                "url": "qk/custom/docRecord/docRecord.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            },
            {
                "id": "cusToTrack",
                "name": "客户池",
                "sort": "3",
                "url": "qk/custom/cusToTrack/cusToTrack.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            },
            {
                "id": "myCustom",
                "name": "我的客户",
                "sort": "4",
                "url": "qk/custom/myCustom/myCustom.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            },
            {
                "id": "myMerch",
                "name": "我的跟单",
                "sort": "6",
                "url": "qk/custom/myMerch/myMerch.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            },
            {
                "id": "myCusToTrack",
                "name": "我的待跟踪客户",
                "sort": "5",
                "url": "qk/custom/myCusToTrack/myCusToTrack.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            },
            {
                "id": "cusAnalysis",
                "name": "客户分析",
                "sort": "7",
                "url": "qk/custom/cusAnalysis/serManager.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            },
            {
                "id": "cusDistr",
                "name": "客户分配",
                "sort": "8",
                "url": "qk/custom/cusDistr/cusDistr.html",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "url": "qk/custom/cusAnalysis/serManager.html"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                    }
                ]
            }
        ]
    }]
}