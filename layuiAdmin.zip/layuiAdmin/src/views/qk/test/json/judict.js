{
    "code": 0,
    "msg": "",
    "data": [{
        "id": "CRM",
        "name": "客户管理",
        "sort": "0",
        "checked": "1",
        "list": [{
                "id": "cusSummary",
                "name": "客户汇总",
                "checked": "1",
                "sort": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    },
                    {
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    },
                    {
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "docRecord",
                "name": "跟单记录",
                "sort": "2",
                "checked": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "cusToTrack",
                "name": "客户池",
                "sort": "3",
                "checked": "0",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "myCustom",
                "name": "我的客户",
                "sort": "4",
                "checked": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "myMerch",
                "name": "我的跟单",
                "sort": "6",
                "checked": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "myCusToTrack",
                "name": "我的待跟踪客户",
                "sort": "5",
                "checked": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "cusAnalysis",
                "name": "客户分析",
                "sort": "7",
                "checked": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            },
            {
                "id": "cusDistr",
                "name": "客户分配",
                "sort": "8",
                "checked": "1",
                "list": [{
                        "id": "detail",
                        "name": "查看",
                        "sort": "0",
                        "checked": "1"
                    },
                    {
                        "id": "add",
                        "sort": "1",
                        "name": "新增",
                        "checked": "1"
                    },
                    {
                        "id": "edit",
                        "sort": "2",
                        "name": "编辑",
                        "checked": "1"
                    },
                    {
                        "id": "del",
                        "sort": "3",
                        "name": "删除",
                        "checked": "1"
                    }
                ]
            }
        ]
    }]
}