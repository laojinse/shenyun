{
    "code": 0,
    "msg": "",
    "data": [{
            "id": "home",
            "name": "快速开始",
            "icon": "layui-icon layui-icon-home",
            "list": [{
                    "id": "console",
                    "name": "工作台",
                    "url": "home/console.html"
                },
                {
                    "id": "TrademarkRetr",
                    "name": "商标检索",
                    "url": "home/TrademarkRetr.html"
                }
            ]
        },
        {
            "id": "custom",
            "name": "客户管理",
            "icon": "layui-icon layui-icon-user",
            "list": [{
                    "id": "cusSummary",
                    "name": "客户汇总",
                    "url": "qk/custom/cusSummary/cusSummary.html"
                },
                {
                    "id": "docRecord",
                    "name": "跟单记录",
                    "url": "qk/custom/docRecord/docRecord.html"
                },
                {
                    "id": "cusToTrack",
                    "name": "客户池",
                    "url": "qk/custom/cusToTrack/cusToTrack.html"
                },
                {
                    "id": "myCustom",
                    "name": "我的客户",
                    "url": "qk/custom/myCustom/myCustom.html"
                },
                {
                    "id": "myMerch",
                    "name": "我的跟单",
                    "url": "qk/custom/myMerch/myMerch.html"
                },
                {
                    "id": "myCusToTrack",
                    "name": "我的待跟踪客户",
                    "url": "qk/custom/myCusToTrack/myCusToTrack.html"
                },
                {
                    "id": "cusAnalysis",
                    "name": "客户分析",
                    "list": [{
                            "id": "serManager",
                            "name": "增长趋势",
                            "url": "qk/custom/cusAnalysis/serManager.html"
                        },
                        {
                            "id": "srcAnalysis",
                            "name": "来源分析",
                            "url": "qk/custom/cusAnalysis/srcAnalysis.html"
                        },
                        {
                            "id": "reqAnalysis",
                            "name": "需求分析",
                            "url": "qk/custom/cusAnalysis/reqAnalysis.html"
                        },
                        {
                            "id": "growthAnalysis",
                            "name": "客户状态",
                            "url": "qk/custom/cusAnalysis/growthAnalysis.html"
                        }
                    ]
                },
                {
                    "id": "cusDistr",
                    "name": "客户分配",
                    "url": "qk/custom/cusDistr/cusDistr.html"
                }
            ]
        },
        {
            "id": "knowledge",
            "name": "知识管理",
            "icon": "layui-icon layui-icon-read",
            "list": [{
                    "id": "allDocs",
                    "name": "所有文档",
                    "url": "qk/knowledge/allDocs/allDocs.html"
                },
                {
                    "id": "shareDocs",
                    "name": "共享文档",
                    "url": "qk/knowledge/shareDocs/shareDocs.html"
                }
            ]
        },
        {
            "id": "home",
            "name": "商标模块",
            "icon": "layui-icon layui-icon-component",
            "list": [{
                    "id": "console",
                    "name": "工作台",
                    "url": "home/console.html"
                },
                {
                    "id": "TrademarkRetr",
                    "name": "商标检索",
                    "url": "home/TrademarkRetr.html"
                }
            ]
        },
        {
            "id": "patent",
            "name": "专利管理",
            "icon": "layui-icon layui-icon-app",
            "list": [{
                "id": "patentManage",
                "name": "专利管理",
                "url": "qk/patent/patentManage/patentManage.html"
            }, {
                "id": "patentApply",
                "name": "专利申请",
                "list": [{
                    "id": "newApply",
                    "name": "新申请",
                    "url": "qk/patent/patentApply/newApply/newApply.html"
                }, {
                    "id": "submit",
                    "name": "提交",
                    "url": "qk/patent/patentApply/submit/submit.html"
                }, {
                    "id": "receivables",
                    "name": "收款",
                    "url": "qk/patent/patentApply/receivables/receivables.html"
                }, {
                    "id": "acceptance",
                    "name": "受理",
                    "url": "qk/patent/patentApply/acceptance/acceptance.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/patentApply/pay/pay.html"
                }, {
                    "id": "toBeAudited",
                    "name": "待审核",
                    "url": "qk/patent/patentApply/toBeAudited/toBeAudited.html"
                }, {
                    "id": "registration",
                    "name": "办理登记",
                    "url": "qk/patent/patentApply/registration/registration.html"
                }, {
                    "id": "authorBullet",
                    "name": "授权公告",
                    "url": "qk/patent/patentApply/authorBullet/authorBullet.html"
                }]
            }, {
                "id": "waitForCert",
                "name": "等待证书",
                "url": "qk/patent/waitForCert/waitForCert.html"
            }, {
                "id": "receiveCert",
                "name": "领取证书",
                "url": "qk/patent/receiveCert/receiveCert.html"
            }, {
                "id": "patentIn",
                "name": "专利转入",
                "url": "qk/patent/patentIn/patentIn.html"
            }, {
                "id": "publiAndTrial",
                "name": "公布和实审",
                "list": [{
                    "id": "publish",
                    "name": "公布",
                    "url": "qk/patent/publiAndTrial/publish/publish.html"
                }, {
                    "id": "trial",
                    "name": "实审",
                    "url": "qk/patent/publiAndTrial/trial/trial.html"
                }]
            }, {
                "id": "specialState",
                "name": "特殊状态",
                "list": [{
                    "id": "submissFail",
                    "name": "提交失败",
                    "url": "qk/patent/specialState/submissFail/submissFail.html"
                }, {
                    "id": "corrections",
                    "name": "补正",
                    "url": "qk/patent/specialState/corrections/corrections.html"
                }, {
                    "id": "reviewOpin",
                    "name": "审查意见",
                    "url": "qk/patent/specialState/reviewOpin/reviewOpin.html"
                }, {
                    "id": "reject",
                    "name": "驳回",
                    "url": "qk/patent/specialState/reject/reject.html"
                }, {
                    "id": "inadmissible",
                    "name": "不予受理",
                    "url": "qk/patent/specialState/inadmissible/inadmissible.html"
                }]
            }, {
                "id": "patentOut",
                "name": "专利转让",
                "list": [{
                    "id": "subTransfer",
                    "name": "提交转让",
                    "url": "qk/patent/patentOut/subTransfer/subTransfer.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/patentOut/pay/pay.html"
                }, {
                    "id": "transResults",
                    "name": "转让结果",
                    "url": "qk/patent/patentOut/transResults/transResults.html"
                }]
            }, {
                "id": "patentChange",
                "name": "专利变更",
                "list": [{
                    "id": "changeSub",
                    "name": "提交转让",
                    "url": "qk/patent/patentChange/changeSub/changeSub.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/patentChange/pay/pay.html"
                }, {
                    "id": "resOfChange",
                    "name": "转让结果",
                    "url": "qk/patent/patentChange/resOfChange/resOfChange.html"
                }]
            }, {
                "id": "assessReport",
                "name": "评价报告",
                "list": [{
                    "id": "subReport",
                    "name": "提交报告",
                    "url": "qk/patent/assessReport/subReport/subReport.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/assessReport/pay/pay.html"
                }, {
                    "id": "recReport",
                    "name": "收到报告",
                    "url": "qk/patent/assessReport/recReport/recReport.html"
                }]
            }, {
                "id": "nullification",
                "name": "无效宣告",
                "list": [{
                    "id": "subDeclare",
                    "name": "提交宣告",
                    "url": "qk/patent/nullification/subDeclare/subDeclare.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/nullification/pay/pay.html"
                }, {
                    "id": "ProcSuccess",
                    "name": "宣告成功",
                    "url": "qk/patent/nullification/ProcSuccess/ProcSuccess.html"
                }]
            }, {
                "id": "perToRecord",
                "name": "许可备案",
                "list": [{
                    "id": "subPermiss",
                    "name": "提交许可",
                    "url": "qk/patent/perToRecord/subPermiss/subPermiss.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/perToRecord/pay/pay.html"
                }, {
                    "id": "LiceSuccess",
                    "name": "许可成功",
                    "url": "qk/patent/perToRecord/LiceSuccess/LiceSuccess.html"
                }]
            }, {
                "id": "otherBus",
                "name": "其他业务",
                "list": [{
                    "id": "subApply",
                    "name": "提交申请",
                    "url": "qk/patent/otherBus/subApply/subApply.html"
                }, {
                    "id": "pay",
                    "name": "缴费",
                    "url": "qk/patent/otherBus/pay/pay.html"
                }, {
                    "id": "dealSuccess",
                    "name": "办理成功",
                    "url": "qk/patent/otherBus/dealSuccess/dealSuccess.html"
                }]
            }, {
                "id": "annFeeManage",
                "name": "年费管理",
                "url": "qk/patent/annFeeManage/annFeeManage.html"
            }, {
                "id": "patentProcess",
                "name": "专利处理过程",
                "url": "qk/patent/patentProcess/patentProcess.html"
            }, {
                "id": "regisFeedback",
                "name": "注册局反馈",
                "url": "qk/patent/regisFeedback/regisFeedback.html"
            }, {
                "id": "patentEdit",
                "name": "专利编辑",
                "url": "qk/patent/patentEdit/patentEdit.html"
            }, {
                "id": "patentDistr",
                "name": "专利分配",
                "url": "qk/patent/patentDistr/patentDistr.html"
            }]
        },
        {
            "id": "app",
            "name": "应用",
            "icon": "layui-icon layui-icon-app",
            "list": [{
                "id": "message",
                "name": "消息中心",
                "url": "app/message/index.html"
            }]
        },
        {
            "id": "senior",
            "name": "高级",
            "icon": "layui-icon layui-icon-senior",
            "list": [{
                "id": "im",
                "name": "LayIM 通讯系统"
            }]
        },
        {
            "id": "system",
            "name": "系统管理",
            "icon": "layui-icon layui-icon-set",
            "list": [{
                    "id": "org",
                    "name": "组织机构",
                    "list": [{
                        "id": "depaManage",
                        "name": "部门管理",
                        "url": "qk/system/org/depaManage/depaManage.html"
                    }, {
                        "id": "jobManage",
                        "name": "职位管理",
                        "url": "qk/system/org/jobManage/jobManage.html"
                    }, {
                        "id": "userManage",
                        "name": "用户管理",
                        "url": "qk/system/org/userManage/userManage.html"
                    }]
                }, {
                    "id": "sysSet",
                    "name": "系统设置",
                    "list": [{
                        "id": "dataDict",
                        "name": "数据字典",
                        "url": "qk/system/sysSet/dataDict/dataDict.html"
                    }, {
                        "id": "classDict",
                        "name": "分类字典",
                        "url": "qk/system/sysSet/classDict/classDict.html"
                    }, {
                        "id": "menuManage",
                        "name": "菜单管理",
                        "url": "qk/system/sysSet/menuManage/menuManage.html"
                    }, {
                        "id": "funcList",
                        "name": "功能列表",
                        "url": "qk/system/sysSet/funcList/funcList.html"
                    }]
                },
                {
                    "id": "opeLog",
                    "name": "操作日志",
                    "url": "qk/system/opeLog/opeLog.html"
                }
            ]
        }
    ]
}