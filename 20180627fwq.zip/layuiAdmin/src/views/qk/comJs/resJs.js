//  公共调用格式
// 设置地址
var indexUrl = 'http://qk.0518360.com/'; //接口地址
var commonUrl = 'http://quanke.0518360.com/'; //网站地址
// var commonUrl = 'http://localhost:8080/layuiAdmin/'; //本地地址
var upLoadUrl = 'http://qk.0518360.com/'; //上传地址
var zonAddrUrl = 'http://apis.map.qq.com/ws/district/v1/list'; //腾讯区划接口




localStorage.setItem('commonUrl', commonUrl);

// 设置jwt/权限网址
var jwt = '';
var comJurUrl = '';
jwt = localStorage.getItem('jwt'); //jwt、session
// 获取权限
// 当前网址
comJurUrl = getComJurUrl(); //获取权限地址
if (localStorage.getItem('comJurUrl')) {
    localStorage.removeItem('comJurUrl');
}
localStorage.setItem('comJurUrl', comJurUrl);
window.addEventListener('hashchange', function () {
    // 获取jwt
    jwt = localStorage.getItem('jwt'); //jwt、session
    // 获取权限
    // 当前网址
    comJurUrl = getComJurUrl(); //获取权限地址
    if (localStorage.getItem('comJurUrl')) {
        localStorage.removeItem('comJurUrl');
    }
    localStorage.setItem('comJurUrl', comJurUrl);
});
window.onload = function () {
    // 获取jwt
    jwt = localStorage.getItem('jwt'); //jwt、session
    // 获取权限
    // 当前网址
    comJurUrl = getComJurUrl(); //获取权限地址
    if (localStorage.getItem('comJurUrl')) {
        localStorage.removeItem('comJurUrl');
    }
    localStorage.setItem('comJurUrl', comJurUrl);
}
//获取权限地址
function getComJurUrl() {
    //获取权限地址
    return (location.hash.search(/#/) !== -1) ? location.hash.replace('#/', '') : location.hash;
}
// 成功码
let resSuc = function (res) {
    return res && res.code === 0;
}
// 成功弹窗
let succMsg = function (res, func) {
    return layer.msg(res.msg ? res.msg : '成功', {
        offset: '15px',
        icon: 1,
        time: 1000
    }, function () {
        func.success && func.success();
    });
}
// 失败弹窗
let failMsg = function (res) {
    return layer.msg(res.msg ? res.msg : '返回数据格式不全或有误', {
        offset: '15px',
        icon: 1,
        time: 1000
    }, function () {
        debugger
        if (res.code === '1') {
            debugger
            //跳转到登入页
            location.hash = '/user/login';
        }
    });
}
// 系统错误弹窗
let errMsg = function (res) {
    return layer.msg(res.msg ? res.msg : '系统未定义错误', {
        offset: '15px',
        icon: 1,
        time: 1000
    });
}
// ajax格式,post
// $.ajaxSettings.xhrFields = {  
//     withCredentials : true  
// };  
function setPost(url, data, options) {
    // debugger
    // jwt = localStorage.getItem('jwt');
    return {
        type: 'post',
        url: `${indexUrl}${url}`,
        dataType: 'json',
        // contentType: "application/json; charset=utf-8",
        // beforeSend: function (request) {
        //     request.setRequestHeader("qksessionid", '1');
        // },
        // headers: {
        //     "qksessionid":jwt
        // },
        data: data,
        // timeout: 6000,
        success: function (res) {
            debugger
            options.success && options.success(res);
        },
        error: function (res) {
            debugger
            options.error && options.error(res);
        }
    }
}
// get
function setGet(url, data, options) {
    debugger
    return {
        type: 'get',
        url: `${indexUrl}${url}`,
        dataType: 'json',
        // contentType: "application/json; charset=utf-8",
        // beforeSend: function (request) {
        //     request.setRequestHeader("qksessionid", '1');
        // },
        // headers: {
        //     "qksessionid":jwt
        // },
        data: data,
        // timeout: 6000,
        success: function (res) {
            options.success && options.success(res);
        },
        error: function (res) {
            options.error && options.error(res);
        }
    }
}

// 外接口get

function setOutGet(url, options) {
    // var script = document.createElement('script');
// script.type = 'text/javascript';

// // 传参并指定回调执行函数为onBack
// script.src = zonAddrUrl;
// document.head.appendChild(script)
    debugger
    return {
        type: 'get',
        url: `${zonAddrUrl}`,
        dataType: 'json',
        crossDomain: true,
        // contentType: "application/json; charset=utf-8",
        // beforeSend: function (request) {
        //     request.setRequestHeader("qksessionid", '1');
        // },
        // headers: {
        //     "qksessionid":jwt
        // },
        data: {key: 'OB4BZ-D4W3U-B7VVO-4PJWW-6TKDJ-WPB77'},
        // timeout: 6000,
        success: function (res) {
            debugger
            if (resSuc(res)) {
                options.success && options.success(res);
            }
        },
        error: function (res) {
            debugger
            options.error && options.error(res);
        }
    }
}
// 公用msg
let comMsg = function (msg) {
    return layer.msg(msg, {
        offset: '15px',
        icon: 1,
        time: 1000
    }, function () {
        debugger

    });
}

// $.ajax(setGet('index.php/home/login/index/action/action', {'qksessionid':jwt}, {
//     success: function (res) {
//         if (resSuc(res)) {
//             succMsg(res, {
//                 success: function () {
//                     debugger
//                 }
//             });
//         } else {
//             failMsg(res);
//         }
//     },
//     error: function (res) {
//         errMsg(errMsg);
//     }
// }))

// $.ajax(setPost('index.php/home/login/index/action/action', {'qksessionid':jwt}, {
//     success: function (res) {
//         if (resSuc(res)) {
//             succMsg(res, {
//                 success: function () {
//                     debugger
//                 }
//             });
//         } else {
//             failMsg(res);
//         }
//     },
//     error: function (res) {
//         errMsg(errMsg);
//     }
// }))