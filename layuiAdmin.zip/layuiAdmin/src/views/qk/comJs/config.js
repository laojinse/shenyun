// 绝对路径
var comUrl = 'http://qk.0518360.com/'; //公共绝对路径