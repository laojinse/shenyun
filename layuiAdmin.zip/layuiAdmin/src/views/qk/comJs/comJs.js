// 数组,按需
Array.prototype.indexOf = function (val) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] == val) return i;
    }
    return -1;
};
Array.prototype.remove = function (val) {
    var index = this.indexOf(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};

//  表单赋值,按需
function preSetFrom(a, b) {
    debugger
    let name = a,
        value = b;
    document.getElementsByName(name)[0].value = value;
    document.getElementsByName(name)[0].text = value;
    document.getElementsByName(name)[0].innerHTML = value;
}

