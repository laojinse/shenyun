const router = require('koa-router')()
const DB = require('../modules/db.js');

router.prefix('/menu')



// 获取列表
router.get('/', async (ctx, next) => {
  console.log('进来了menu 目标获取目录列表');
  //设置基础值 data就是 列表项 传输出去的值 也是这个
 
  // 获取所有菜单的值 数据表 
  let dk =  await DB.find('menuS',{}) ;
  // 在这个位置生成菜单JSON
  let menuArry = []
        
  // 循环生成一级表单
  for(var k=0; k<dk.length; k++){
      // 判断
      if(dk[k].dengji == 1){
          // 如果没有父级 创建一级菜单 
          menuArry.push(dk[k])
      }
  }
  // 先把2存出来,再把3添加到2中，最后把2 添加到1 中
  var dj2Arry = []
        
  // 循环生成二级表单
  for(var m=0; m<dk.length; m++){
      // 如果是二级菜单
      if(dk[m].dengji ==2 ){
          // 存出二级菜单，然后循环该数组将三级菜单存入
          dj2Arry.push(dk[m])
      }
  }
  // 循环生成三级表单 并存入 二级菜单中
  for(var j=0; j<dk.length; j++){
      // 如果是三级菜单
      if(dk[j].dengji ==3){
            // 向父级数组List中添加
          for(var mm=0; mm<dj2Arry.length; mm++){
              // 判断，如果寻找id值相等的父级
              if(dj2Arry[mm]._id == dk[j].parent){
                  // 填充相应的三级列表到 二级数组中
                  dj2Arry[mm].list.push({"name": dk[j].jump,"title":dk[j].title})
              }
          }
      }
  }
  //最后一步 把2存到1中
  for(var m=0; m<dj2Arry.length; m++){
      // 向父级数组List中添加
      for(var mm=0; mm<menuArry.length; mm++){
          // 判断，如果寻找id值相等的父级
          if(menuArry[mm]._id == dj2Arry[m].parent && dj2Arry[m].list.length>0){
              menuArry[mm].list.push({"name" : dj2Arry[m].jump , "title" : dj2Arry[m].title ,"list" : dj2Arry[m].list})
          }
          if(menuArry[mm]._id == dj2Arry[m].parent && dj2Arry[m].list.length == 0){
            menuArry[mm].list.push({"name" : dj2Arry[m].name , "title" : dj2Arry[m].title ,"jump" : dj2Arry[m].jump})
        }
      }
    
  }
  let  menuL = { "code": "0" ,"msg": "这是msg的值" ,"data": menuArry} ;

  ctx.body = menuL
})




// 添加菜单
router.get('/addmenu', async (ctx, next) => {

  //第一步 存该值到 menuS表中
    ctx.query.list =[];  //加入list=[] 

    let data = await DB.insert('menuS',ctx.query)

    console.log()

  //第二步 返回上一页刷新上一页页面
    try{
        if(data.result.ok){
          ctx.body = '<script>window.history.back(-1); </script>'
        }
    }catch(err){
        ctx.body = '<script>alert("服务器链接超时")window.history.back(-1); </script>'
    }

  await next();

})

// 获取菜单列表给 select
router.get('/menuList', async(ctx,next) =>{

  //向接口拿数据[只拿一二级]
  let data = await DB.find('menuS',{}); //拿到所有的菜单
  data.sort(compareAsc("paixu"))  //排序
  let ajdata = []   //存放去除掉三级菜单后的 菜单集合

  for(i=0; i<data.length; i++){
    if(data[i].dengji == 1 ){
      ajdata.push(data[i])
    }
  }
  for(i=0; i<data.length; i++){
    if(data[i].dengji == 2 ){
      ajdata.push(data[i])
    }
  }
  ctx.body = ajdata

} )

//向接口拿数据【拿全部 】
router.get('/menuList2', async(ctx,next) =>{

  let data = await DB.find('menuS',{}); //拿到所有的菜单
  data.sort(compareAsc("paixu"))  //排序
 
  ctx.body = {"code":0,"msg":"","count":data.length,"data":data}

} )


// 查询一条数据
router.get('/findOne', async(ctx,next)=>{
    // console.log(ctx.query._id)
   let data = await DB.find("menuS",{'_id': DB.getObjectId(ctx.query._id)})

   ctx.body = data
})

// 修改数据接口
router.get('/menuChange', async(ctx,next)=>{
  
  let data = await DB.update("menuS",{'_id': DB.getObjectId(ctx.query._id)},{'name':ctx.query.name,'icon':ctx.query.icon,'jump':ctx.query.jump,'paixu':ctx.query.paixu})

  //第二步 返回上一页刷新上一页页面
  try{
    if(data.result.ok){
      ctx.body = '1'
    }
  }catch(err){
      ctx.body = '2'
  }


})





// json排序
function compareDesc(propertyName) {  
  return function(object1, object2) {  
      var value1 = object1[propertyName];  
      var value2 = object2[propertyName];  
      if(value2 < value1) {  
          return -1;  
      } else if(value2 > value1) {  
          return 1;  
      } else {  
          return 0;  
      }  
  }  
}  
// json排序
function compareAsc(propertyName) {  
  return function(object1, object2) {  
      var value1 = object1[propertyName];  
      var value2 = object2[propertyName];  
      if(value2 < value1) {  
          return 1;  
      } else if(value2 > value1) {  
          return -1;  
      } else {  
          return 0;  
      }  
  }  
}  


 
module.exports = router
